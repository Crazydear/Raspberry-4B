# Pi Dashboard
A WebUI dashboard for IoT devices likes raspberry pi.

Project details: (https://make.quwj.com/project/10)

Copyright 2017-2020 NXEZ.com.

Licensed under the GPL v3.0 license.